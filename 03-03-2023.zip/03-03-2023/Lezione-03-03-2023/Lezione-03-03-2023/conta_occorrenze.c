#define _CRT_SECURE_NO_WARNINGS
#include<stdlib.h>
#include<stdint.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>

int ContaOccorrenze(const char* filename, const char* str) {
	if (filename == NULL)
		return 0;
	if (str == NULL || strlen(str) < 1)
		return 0;

	FILE *f = fopen(filename, "r");
	if (f == NULL)
		return 0;

	int counter = 0;
	char* read = malloc(sizeof(char)*99);
	while (1) {
		int ret = fscanf(f, "%[^ \n]\n", read);
		
		if (ret != 1)
			break;
		
		if (strcmp(read, str) == 0)
			counter++;
	}
	fclose(f);
	free(read);
	return counter;
}

/*
int main() {

	ContaOccorrenze("file2.txt", "file");
	return 0;
}
*/