int ProdottoNegativi(int a, int b) {
	if (b == 0 || a == 0)
		return 0;
	
	if (b > 0)
		return ProdottoNegativiRec(a, b);
	else
		return -1 * ProdottoNegativiRec(a, -b);
	
}

int ProdottoNegativiRec(int a, int b) {
	if (b == 1)
		return a;

	return a + ProdottoNegativiRec(a, b - 1);
}