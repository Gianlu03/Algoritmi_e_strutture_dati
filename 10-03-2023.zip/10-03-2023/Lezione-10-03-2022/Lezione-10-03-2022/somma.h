#ifndef SOMMA_H
#define SOMMA_H

extern int sommaFinoA(int n);


#endif /* SOMMA_H */