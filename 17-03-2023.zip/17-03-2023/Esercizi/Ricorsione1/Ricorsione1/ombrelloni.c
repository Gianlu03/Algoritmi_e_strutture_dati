#include<stdlib.h>
#include<stdbool.h>
#include<stdio.h>

void OmbrelloniRec(int k, int n, int i, bool* vcurr, int cnt, int* nsol) {

	if (cnt == k) {
		(*nsol)++;
		printf("%4d) ", *nsol);
		for (int j = 0; j < n; j++)
			printf("%d ", vcurr[j]);
		printf("\n");

		return;
	}

	if (i >= n) {   //se non � entrato nel caso cnt = k non � soluzione e torna indietro
		return;
	}

	//caso generico

	vcurr[i] = 0;
	OmbrelloniRec(k, n, i + 1, vcurr, cnt, nsol);

	vcurr[i] = 1;
	if(i < n - 1) //controllo il valore per non scrivere oltre
		vcurr[i + 1] = 0;
	OmbrelloniRec(k, n, i + 2, vcurr, cnt + 1, nsol);
	vcurr[i] = 0; // pulisco le scelte 

}

int Ombrelloni(int k, int n) {
	if (n < 0 || k < 0)
		return 0;

	bool* vcurr = calloc(n, sizeof(bool));
	int nsol = 0;

	OmbrelloniRec(k, n, 0, vcurr, 0, &nsol);

	free(vcurr);

	return nsol;

}


/*
int main(void) {

	Ombrelloni(3, 9);

	return 0;
}
*/