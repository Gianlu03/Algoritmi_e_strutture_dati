#include<stdbool.h>
#include<stdlib.h>
#include<stdio.h>

//puntatori cos� che siano modificate e visibili aggiornate ad ogni livello
//le altre no in questo modo quanto torna su con rollback ritorna il valore originale

//Le foglie si trovano al livello i = n


void subsetkRec(int n, int k, bool* vcurr, int i, int* nsol) {
	if (i == n) { // sono ad una foglia
		int cnt;
		for (int j = 0; j < n; j++) {
			if (vcurr[j]) {
				cnt++;
			}
		}

		if (cnt == k) { //la soluzione � valida
			nsol++; // conto le soluzioni valide
			for(int j = 0; j < n; ++j)
				if(vcurr[j])
					printf("%i", j);
		}

		return; //cos� il caso base ferma tutto
	}
	
	vcurr[i] = 0;		//scrivere un valore in vcurr significa fare una scelta al livello i
	subsetkRec(n, k, vcurr, i + 1, nsol);	// i aumenta perch� scendo di livello

	vcurr[i] = 1;		
	subsetkRec(n, k, vcurr, i + 1, nsol);
	vcurr[i] = 0;

}

//questa � la funzione usata nel main, prepara tutto poi richiama la ricorsiva
int subsetk(int n, int k) {
	bool* vcurr = calloc(n, sizeof(bool));
	int nsol = 0;

	subsetkRec(n, k, vcurr, 0, &nsol);

	free(vcurr);
	return nsol;
}


int main(void) {
	int nsol = subsetk(4, 2);

}