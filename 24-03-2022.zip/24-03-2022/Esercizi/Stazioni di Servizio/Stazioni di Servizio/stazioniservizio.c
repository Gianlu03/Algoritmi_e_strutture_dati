#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#include<string.h>

void StazioniServizioRec(double m, const double* d, const double* p, size_t n, bool *vcurr, double actualPrice, double tank, bool *best, double *bestPrice, int *nStations, int count, int i, double km) {
	//mi fermo o se non arrivo alla tappa oppure se con l'ultima fermata non arrivo alla distanza finale
	if (i < n && d[i] > tank * 20 || i == n && tank*20 < m - km) 
		return;

	//posso arrivare
	if (i == n) { // l'importante � che si abbia la possibilit� di arrivare all'ultima stazione
		if (actualPrice < *bestPrice) {
			*bestPrice = actualPrice;
			*nStations = count;
			memcpy(best, vcurr, n);
		}
		return;
	}


	vcurr[i] = 0; //non mi fermo
	StazioniServizioRec(m, d, p, n, vcurr, actualPrice, tank - d[i]*0.05, best, bestPrice, nStations, count, i + 1, km + d[i]);

	vcurr[i] = 1; //mi fermo
	StazioniServizioRec(m, d, p, n, vcurr, actualPrice + (30.0 - (tank - 0.05 * d[i])) * p[i], 30, best, bestPrice, nStations, count + 1, i + 1, km + d[i]);
	vcurr[i] = 0;												//la tratta � percorsa prima di rifornire
}

void StazioniServizio(double m, const double* d, const double* p, size_t n) {
	// 30 litri * 0,05 l/km -> 1l = 20km   30l = 600km

	double totDist = 0;
	for (int i = 0; i < n; i++) {
		totDist += d[i];
	}
	totDist += 30 * 20;

	//Se devo arrivare oltre il possibile con la benzina dell'ultima stazione il problema � impossibile
	if (totDist < m) {
		printf("Non esistono soluzioni");
		return;
	}

	bool* vcurr = malloc(sizeof(bool) * n);
	bool* best = malloc(sizeof(bool) * n);

	double bestPrice = 0;
	for (int i = 0; i < n; i++)
		bestPrice += p[i] * 30;
	int nStations = 0;

	StazioniServizioRec(m, d, p, n, vcurr, 0, 30.0, best, &bestPrice, &nStations, 0, 0, 0);

	/* STAMPA */

	if (nStations == 0){
		printf("Non esistono soluzioni");
		free(best);
		free(vcurr);
		return;
	}		

	for (int i = 0, c = 0; i < n, c < nStations; i++) {
		if (best[i]) {
			printf("%d ", i);
			c++;
		}
			
	}
	printf("\n");
	printf("Spesa totale: %lf euro", bestPrice);
	free(best);
	free(vcurr);
}



/*
int main(void) {
	double m = 2020;
	
	double d[5] = {260, 284, 308, 332, 356};
	double p[5] = {35, 35, 33, 29, 23};
	size_t n = 5;

	StazioniServizio(m, d, p, n);

	return 0;
}
*/
