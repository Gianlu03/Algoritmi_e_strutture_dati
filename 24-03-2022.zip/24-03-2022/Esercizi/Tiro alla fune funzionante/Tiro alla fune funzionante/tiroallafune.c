#define CRT_SECURE_NO_WARNINGS

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<math.h>

void tiroallafuneRec(int* I, size_t n, bool* A, size_t dimA, int* minDiff, bool* bestA, int count, int i) {

	/* CASO BASE: SE HO PRESO DIM ELEMENTI MI FERMO */
	if (count == dimA) {
		int diff = 0;
		for (int k = 0; k < n; k++) {
			if (A[k])
				diff += I[k];
			else
				diff -= I[k];
		}
		diff = abs(diff);

		if (diff < *minDiff) {
			memcpy(bestA, A, n);
			*minDiff = diff;
		}
		return;
	}

	if (i == n)
		return;

	/* CASO GENERALE */

	// (non prendo in A)
	A[i] = false;
	tiroallafuneRec(I, n, A, dimA, minDiff, bestA, count, i + 1);

	// (prendo in A)
	A[i] = true;
	tiroallafuneRec(I, n, A, dimA, minDiff, bestA, count + 1, i + 1);
	A[i] = false;
}

int main(int argc, char* argv[]) {

	size_t n = argc - 1;

	size_t dimA = n / 2;
	size_t dimB = n / 2;

	if (n % 2)
		dimB++;

	int* I = calloc(n, sizeof(int));

	bool* A = calloc(n, sizeof(bool));
	bool* bestA = calloc(n, sizeof(bool));

	int mindiff = 0;

	//mettendoci il valore assoluto della somma di tutti + 1 sicuramente � sopra 
	for (int i = 1; i <= n; i++) {
		I[i - 1] = atoi(argv[i]);
		mindiff += abs(I[i - 1]);
	}
	mindiff++;

	tiroallafuneRec(I, n, A, dimA, &mindiff, bestA, 0, 0);

	/* STAMPO A */
	int c = 0;

	printf("{ ");
	for (int k = 0; k < n; k++) {
		if (bestA[k]) { //se 1 � in A
			c++;
			printf("%d", I[k]);
			if (c < dimA)
				printf(", ");
		}
	}
	printf(" }, ");

	//stampo B
	c = 0;

	printf("{ ");
	for (int k = 0; k < n; k++) {
		if (!bestA[k]) { //se 0 � in B
			c++;
			printf("%d", I[k]);
			if (c < dimB)
				printf(", ");
		}
	}
	printf(" }");

	free(A);
	free(bestA);

	return 0;
}