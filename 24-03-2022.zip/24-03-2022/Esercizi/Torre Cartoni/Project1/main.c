#include"torrecartoni.h"

int main(void) {

	Cartone* c = malloc(sizeof(Cartone) * 3);
	c[0].p = 10; //021
	c[0].a = 20;
	c[0].l = 40;

	c[1].p = 10;
	c[1].a = 10;
	c[1].l = 8;

	c[2].p = 9;
	c[2].a = 3;
	c[2].l = 5;

	size_t n = 3;

	TorreCartoni(c, n);

	return 0;
}