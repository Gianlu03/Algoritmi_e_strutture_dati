#include"torrecartoni.h"

bool isUsed(int index, size_t n, int* pila) {
	bool used = false;
	for (int k = 0; k < n; k++) {
		//Controllo se gi� usato
		if (pila[k] == index)
			used = true;
	}
	return used;
}

void TorreCartoniRec(const Cartone* c, size_t n, int* pila, int* best, int pesoAttuale, int altezzaAttuale, int count, int* altezzaBest, int* npacchiBest, int i) {

	 if (i == n)
		 return;

	//caso generale
	for (int j = 0; j < n; j++) {
		bool used = isUsed(j, n, pila);
		
		if (used) continue;

		if (c[j].l >= pesoAttuale) {
			
			//Se il pacco regge lo metto sotto
			pila[i] = j;

			//Se ho superato il best lo aggiorno
			if (altezzaAttuale + c[j].a > *altezzaBest) {
				*altezzaBest = altezzaAttuale + c[j].a;
				*npacchiBest = count + 1;

				memcpy(best, pila, sizeof(int)*n);
			}

			TorreCartoniRec(c, n, pila, best, pesoAttuale + c[j].p, altezzaAttuale + c[j].a, count+1, altezzaBest, npacchiBest , i + 1);
			pila[i] = -1;
		}

	}


}

 void TorreCartoni(const Cartone* c, size_t n) {

	if (c == NULL || n == 0)
		return;

	int* pila = malloc(sizeof(int) * n);
	int pesoAttuale = 0;
	int altezzaAttuale = 0;
	int count = 0;

	int* best = malloc(sizeof(int) * n);
	int altezzaBest = 0;
	int npacchiBest = 0;

	int i = 0;

	for (int i = 0; i < n; i++) {
		pila[i] = -1;
		best[i] = -1;
	}

	TorreCartoniRec(c, n, pila, best, pesoAttuale, altezzaAttuale, count, &altezzaBest, &npacchiBest, i);


	//stampa pila migliore
	for (int j = 0; j < npacchiBest; j++) {
		printf("%d\n", best[j]);
	}
	printf("Altezza: %d cm", altezzaBest);

	free(best);
	free(pila);

}
