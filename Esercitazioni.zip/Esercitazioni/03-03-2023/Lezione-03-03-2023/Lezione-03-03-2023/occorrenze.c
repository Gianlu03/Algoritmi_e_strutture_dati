/*#define _CRT_SECURE_NO_WARNINGS
#include<stdlib.h>
#include<stdint.h>
#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main(int args, char *argv[]) {
	if (args != 3) {
		fprintf(stderr, "Il numero di parametri non e' corretto. Sintassi del programma: \"occorrenze <s> <c>\"");
		return 1;
	}

	int counter = 0;
	for (size_t i = 0; i < strlen(argv[1]); i++) {
		if(argv[1][i] == argv[2][0])
			counter++;
	}
	
	printf("%d", counter);

	return 0;
}
*/