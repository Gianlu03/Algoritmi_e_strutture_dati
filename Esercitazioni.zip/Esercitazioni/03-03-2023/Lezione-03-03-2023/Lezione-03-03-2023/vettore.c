/*
#include"vettore.h"

void Push(struct vettore* v, int d) {
	if (v == NULL)
		return;

	v->data = realloc(v->data, sizeof(int) * (v->size + 1));
	v->data[v->size] = d;
	v->size++;
	
}

int Pop(struct vettore* v) {
	if (v == NULL)
		return;

	int popped = v->data[0];
	for (size_t i = 0; i < v->size - 1; i++) {
		v->data[i] = v->data[i + 1];
	}
	v->data = realloc(v->data, sizeof(int) * (v->size - 1));

	v->size--;
	return popped;
}


int main() {

	struct vettore* v = malloc(sizeof(struct vettore));
	v->size = 3;
	v->data = malloc(sizeof(int) * v->size);
	v->data[0] = 3;
	v->data[1] = 4;
	v->data[2] = 7;

	int popped = Pop(v);
	Push(v, 10);
}
*/