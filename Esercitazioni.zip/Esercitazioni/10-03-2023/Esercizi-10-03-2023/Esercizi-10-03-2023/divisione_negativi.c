#include<math.h>
#include<limits.h>

int DivisioneNegativi(int a, int b) {
	if (b == 0)
		return INT_MAX;

	int sign = 0;
	if (a < 0)
		sign++;
	if (b < 0)
		sign++;

	if(sign % 2) // dispari
		return -DivisioneNegativiRec(abs(a), abs(b));

	return DivisioneNegativiRec(abs(a), abs(b));
}

int DivisioneNegativiRec(int a, int b) {
	if (a < b)
		return 0;

	return 1 + DivisioneNegativiRec(a - b, b);
}
