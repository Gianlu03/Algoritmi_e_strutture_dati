extern unsigned long long Fattoriale(int n);
extern int Minimo(const int* v, int v_size);
extern int fibonacci(int n);
extern int Prodotto(int a, int b);
extern int ProdottoNegativi(int a, int b);
extern int Divisione(int a, int b);
extern int DivisioneNegativi(int a, int b);


int main(void) {

	//Fattoriale(5);
	
	//int v[] = {44, 34, 54, 82, 344};
	//int min = Minimo(v, 5);


	// 0 1 1 2 3 5 8 13 21
	//int n = 4;
	//int f = Fibonacci(8);

	//int p = Prodotto(70, 0);
	//int p2 = ProdottoNegativi(-6, -5);
	
	//int d = Divisione(4, 0);

	int d2 = DivisioneNegativi(-1, 0);

	return 0;
}