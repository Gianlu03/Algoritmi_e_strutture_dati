#include<math.h>
int Minimo(const int* v, int v_size) {
	if (v_size == 1)
		return v[0];

	return fmin(v[v_size - 1], Minimo(v, v_size - 1));
}
