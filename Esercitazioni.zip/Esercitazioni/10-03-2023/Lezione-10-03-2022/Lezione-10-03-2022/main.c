#include "somma.h"

int main(void) {
	
	//n*(n+1)/2 trovi velocemente la somma degli elementi
	 
	int s = sommaFinoA(5);

	return 0;
}