#include"somma.h"

//funzione ausilaria, non � definita nel .h in quanto
//funzione interna, richiamandola direttamente si rischierebbero errori

static int sommaFinoA(int n) {
	//Caso particolare
	if (n <= 0)
		return -1;

	return sommaFinoArec(n);
}

int sommaFinoArec(int n) {
	if (n == 1)
		return 1;

	return n + sommaFinoArec(n - 1);
}