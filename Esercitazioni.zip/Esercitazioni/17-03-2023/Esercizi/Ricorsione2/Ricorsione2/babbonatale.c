#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>

void BabboNataleRec(const int* pacchi, size_t pacchi_size, int p, int actualp, int i, int cnt, int* cntMax, bool* vcurr, bool* best) {

	if (actualp == p || i == pacchi_size) {
		if (cnt > (* cntMax)) {
			*cntMax = cnt;
			for (int j = 0; j < pacchi_size; j++)
				best[j] = vcurr[j];
		}
		return;
	}

	//non prendo il pacco
	vcurr[i] = 0;
	BabboNataleRec(pacchi, pacchi_size, p, actualp, i + 1, cnt, cntMax, vcurr, best);

	//prendo il pacco se posso
	if (actualp + pacchi[i] <= p) {
		vcurr[i] = 1;
		BabboNataleRec(pacchi, pacchi_size, p, actualp + pacchi[i], i + 1, cnt + 1, cntMax, vcurr, best);
	}
}

void BabboNatale(const int* pacchi, size_t pacchi_size, int p) {
	if (p <= 0 || pacchi == NULL || pacchi_size <= 0)
		return;

	bool* best = calloc(pacchi_size, sizeof(bool));
	bool* vcurr = calloc(pacchi_size, sizeof(bool));
	int cntMax = 0;

	BabboNataleRec(pacchi, pacchi_size, p, 0, 0, 0, &cntMax, vcurr, best);

	for (int j = 0; j < pacchi_size; j++) {
		printf("%d ", best[j]);
	}

	free(best);
	free(vcurr);
}

/*
int main(void) {

	int pacchi[] = {3, 6, 3, 2};
	BabboNatale(pacchi, 4, 10);

	return 0;
}
*/